/*
 * Key.h
 *
 *  Created on: 2024��1��24��
 *      Author: A
 */

#ifndef CODE_KEY_H_
#define CODE_KEY_H_

// �궨��
//#define Key1  P22_0
//#define Key2  P22_1
//#define Key3  P22_2
//#define Key4  P22_3
#define Key1  P11_3
#define Key2  P11_2
#define Key3  P20_7
#define Key4  P20_6
#define Switch5   P33_11
#define Switch6   P33_12


// ȫ�ֱ�������
extern uint8 key1_flag;
extern uint8 key2_flag;
extern uint8 key3_flag;
extern uint8 key4_flag;
extern uint8 switch5_flag;
extern uint8 switch6_flag;

// ��������

void Key_init(void);
void Key_scan(void);

#endif /* CODE_KEY_H_ */
