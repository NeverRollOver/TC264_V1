/*
 * control.h
 *
 *  Created on: 2024��4��25��
 *      Author: 86177
 */

#ifndef CODE_CONTROL_H_
#define CODE_CONTROL_H_
/******************************************ͷ�ļ�����*******************************************/
#include "zf_common_headfile.h"

/******************************************�궨��*******************************************/
#define MID_W 84;

/******************************************ȫ�ֱ�������*******************************************/
extern uint16 dianji_value;
extern uint16 duoji_value;

/******************************************��������*******************************************/
//void control_init(void);
void control_StraightForward(void);

#endif /* CODE_CONTROL_H_ */
