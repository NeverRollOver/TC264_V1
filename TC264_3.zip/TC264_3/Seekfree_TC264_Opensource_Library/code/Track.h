/*
 * Track.h
 *
 *  Created on: 2024��3��23��
 *      Author: 25378
 */

#ifndef CODE_TRACK_H_
#define CODE_TRACK_H_

// �궨��
#define Black 0
#define White 255
#define CAMERA_SIZE 30

#define GrayScale 256
#define IMAGE_H    50//ͼ��߶�
#define IMAGE_W    90//ͼ�����

// ��������
void Screen_init(void);
void Screen_showimg(void);
void Image_Binarization(uint8 *dst, uint8 *src, uint8 threshold);

void Image_Binarization_v2();
void otsuThreshold_v0();
//void ImageProcess();
void FindCenterLine();

uint8 otsuThreshold(uint8 *image);
void compressimage(void);
void sobel (uint8 imageIn[IMAGE_H][IMAGE_W], uint8 imageOut[IMAGE_H][IMAGE_W], uint8 Threshold);
void image_draw_rectan(uint8(*image)[IMAGE_W]);
void clear_find_point(void);
int16 calc_diff(int16 x, int16 y);
float limit(float x, int32 y);
float Get_angle(float Ax, float Ay, float Bx, float By, float Cx, float Cy);




#endif /* CODE_TRACK_H_ */
