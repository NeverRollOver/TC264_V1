/*
 * stateMachine.c
 *
 *  Created on: 2024��4��24��
 *      Author: 86177
 */
#include "stateMachine.h"

STATEMACHINE_Enum state_machine = image_threshold;//״̬��ʼ��
/*
static void state_1(void);
static void state_2(void);
//StateMent[hello_state]()
void (*StateMent[])()={
        state_1,
        state_2,
};
void state_1(void)
{

}
void state_2(void)
{

}
*/
//��������״̬��Ծ ����Ծ
void jumpstate_add(void)
{
    if(state_machine = car_runORstop)
    {
        state_machine=images_value;
    }
    else
    {
        state_machine++;
    }

}

//��������״̬��Ծ ����Ծ
void jumpstate_reduce(void)
{
    if(state_machine = images_value)
    {
        state_machine = car_runORstop;
    }
    else
    {
        state_machine--;
    }
}
