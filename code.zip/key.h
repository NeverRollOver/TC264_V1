/*
 * key.h
 *
 *  Created on: 2024��4��24��
 *      Author: 86177
 */

#ifndef CODE_KEY_H_
#define CODE_KEY_H_
/******************************************ͷ�ļ�����*******************************************/
#include "zf_common_headfile.h"
//#include


/******************************************�궨��*******************************************/
#define key1   P11_3
#define key2   P11_2
#define key3   P20_7
#define key4   P20_6
#define key5   P33_11
#define key6   P33_12
//#define


/******************************************ȫ�ֱ�������*******************************************/
extern uint8 key1_flag;
extern uint8 key2_flag;
extern uint8 key3_flag;
extern uint8 key4_flag;
extern uint8 key_val;
//extern


/******************************************��������*******************************************/
void Key_init(void);//������ʼ��
void key_scan(void);//����ɨ��
//void




#endif /* CODE_KEY_H_ */
