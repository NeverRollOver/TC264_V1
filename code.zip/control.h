/*
 * control.h
 *
 *  Created on: 2024��4��25��
 *      Author: 86177
 */

#ifndef CODE_CONTROL_H_
#define CODE_CONTROL_H_
/******************************************ͷ�ļ�����*******************************************/
#include "zf_common_headfile.h"
//#include


/******************************************�궨��*******************************************/
#define MID_W 84;
//#define


/******************************************ȫ�ֱ�������*******************************************/
extern uint16 dianji_value;
extern uint16 duoji_value;
//extern


/******************************************��������*******************************************/
void control_init(void);
//void duoji_duty_update(uint8 mid,float kp);
//void





#endif /* CODE_CONTROL_H_ */
